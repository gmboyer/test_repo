def say_hello(say="hello"):
    """
    Says hello, or whatever you want
    
    Parameters
    ----------
    say : str
        Desired thing to say
    """
    
    print("Hello")